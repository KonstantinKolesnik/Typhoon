Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Bluetooth Chat")> 
<Assembly: AssemblyDescription("32feet.NET Bluetooth Chat (Pocket PC)")> 
<Assembly: AssemblyCompany("In The Hand Ltd")> 
<Assembly: AssemblyProduct("32feet.NET")> 
<Assembly: AssemblyCopyright("Copyright � 2004-2007 In The Hand Ltd")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("2.1.0207.0")> 
