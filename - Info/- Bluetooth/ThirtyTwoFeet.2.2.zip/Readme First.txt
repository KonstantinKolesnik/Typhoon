32feet.NET - Personal Area Networking for .NET
==============================================

Version 2.2 (22nd November 2007)

Installation
------------
This .ZIP file contains two installation files:
Setup.exe
ThirtyTwoFeet.Setup.msi

To ensure the package is correctly installed under Windows Vista make sure you use the Setup.exe provided and don't launch the .MSI file directly.

For more information see http://inthehand.com/content/32feet.aspx

Peter Foot
In The Hand Ltd