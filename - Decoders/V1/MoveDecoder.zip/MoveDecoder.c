//------------------------------------------------------------------------
//
// OpenDCC - OpenDecoder
//
// Copyright (c) 2006 Kufer
//
// This source file is subject of the GNU general public license 2,
// that is available at the world-wide-web at
// http://www.gnu.org/licenses/gpl.txt
// 
//------------------------------------------------------------------------
//
// file:      MoveDecoder.c
// author:    Wolfgang Kufer
// contact:   kufer@gmx.de
// webpage:   http://www.opendcc.de
// history:   2006-07-30 V0.1 start
//            2006-08-20 V0.2 change in motor params and remote control
//
//------------------------------------------------------------------------
//
// purpose:   flexible, lowcost decoder for dcc
//            use as motor controller for moving accessory
//
// content:   A DCC-Decoder for ATtiny2313 and other AVR
//
//             1. Defines and variable definitions
//             2. DCC receive routine
//             3. Timing engine (pwm)
//             4. Motor State Engine
//             5. MAIN: analyze command, call the action, do programming
//             6. Test and Simulation
//
//------------------------------------------------------------------------

#include <stdlib.h>
#include <stdbool.h>
#include <inttypes.h>
#include <avr/pgmspace.h>        // put var to program memory
#include <avr/io.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>

#define SIMULATION  0            // 0: real application
                                 // 1: test receive routine
                                 // 2: test timing engine (toggle fast)
                                 // 3: test motor

//---------------------------------------------------------------------
// Timing Definitions: (all values in us)
//
#ifndef F_CPU
   // prevent compiler error by supplying a default 
   # warning "F_CPU not defined for <MoveDecoder.c>", set default to 10MHz 
   # define F_CPU 10000000UL
   // if changed: check every place where it is used
   // (possible range underflow/overflow in preprocessor!)
#endif


/// This are DCC timing definitions from NMRA
#define PERIOD_1   116L          // 116us for DCC 1 pulse - do not change
#define PERIOD_0   232L          // 232us for DCC 0 pulse - do not change



//---------------------------------------------------------------------
// Definition for Motor and other timing

// Timer0 runs a phase correct pwm, prescaler 1; this makes an int every 510 cycles
// This 510 Cycles are PWM_TICK_PERIOD [unit: us];
// In the ISR a counter is incremented til SW_TIMER_MAX is reached.
// This event sets a flag that an increment step should happen.
// Therefore SW_TIMER_MAX is calculated as follows:
//
//                            RAMP_TIME
//    SW_TIMER_MAX = ---------------------------------
//                    No_of_STEPS  *  TIME_RESOLUTION
//
// The period time of the flag is: 
//
//    SW_TICK_PERIOD = PWM_TICK_PERIOD * SW_TIMER_MAX    
//
// All sw timings are related to SW_TICK_PERIOD
//

#define TIMER0_CLKDIV 1              // possible values: 1, 8, 64, 256, 1024
#define PWM_TICK_PERIOD (510L * 1000000L * TIMER0_CLKDIV / F_CPU)   // in us

#define RAMP_TIME        (20*1000000L)       // 20s: Zeit f�r eine volle PWM-Rampe 
                                             // (beschleunigen 0..255)

#define OSCILLATE_TIME   (100*1000000L)       // 100s: Pendelzeit

#define SW_TIMER_MAX     (RAMP_TIME / 256L / PWM_TICK_PERIOD)  

#define SW_TICK_PERIOD   (PWM_TICK_PERIOD * SW_TIMER_MAX)       


//---------------------------------------------------------------------------
// PORT Definitions:
//
// PORTD:
#define PROGTASTER    0
#define DCCIN         2     // must be located on INT0
#define JUMPER        4     // if Jumper fitted: state is saved in EEPROM
#define LED           6     // output

#define PROG_PRESSED   (!(PIND & (1<<PROGTASTER)))
#define JUMPER_FITTED  (!(PIND & (1<<JUMPER)))
#define LED_OFF        PORTD &= ~(1<<LED)
#define LED_ON         PORTD |= (1<<LED)
#define LED_TOGGLE     PORTD ^= (1<<LED)


// PORTB:
// wir benutzen PORTB als Input - Output f�r Motor und R�ckmeldesensoren
//
#define KEY_GO_A     0     // in:  external tracer: "run to A"
#define KEY_GO_B     1     // in:  external tracer: "run to B"
#define MOTOR_PWM    2     // out: PortB, OC0A -> Compare Match Timer0
#define MOTOR_DIR    3     // out: Direction: 1=run towards A, 0=towards B
#define STOP_A       4     // in:  Sensor: End at A
#define BRAKE_A      5     // in:  Sensor: Brake Position at A
#define STOP_B       6     // in:  Sensor: End at B
#define BRAKE_B      7     // in:  Sensor: Brake Position at B


#define KEY_GO_A_PRESSED   (!(PINB & (1<<KEY_GO_A)))
#define KEY_GO_B_PRESSED   (!(PINB & (1<<KEY_GO_B)))
#define MOTOR_TO_A         PORTB |= (1<<MOTOR_DIR)
#define MOTOR_TO_B         PORTB &= ~(1<<MOTOR_DIR)
#define STOP_A_REACHED     (PINB & (1<<STOP_A))          // active high
#define BRAKE_A_REACHED    (PINB & (1<<BRAKE_A))
#define STOP_B_REACHED     (PINB & (1<<STOP_B))
#define BRAKE_B_REACHED    (PINB & (1<<BRAKE_B))


unsigned char move_state;
#define MS_STOPPED     0        // default after power up
#define MS_RUN_TO_A    1
#define MS_AT_A        2
#define MS_RUN_TO_B    3
#define MS_AT_B        4


//
//----------------------------------------------------------------------------
// Global Data

// unsigned int  MyAdr;               // my DCC address
unsigned char MyOpMode;            // mode of operation

volatile unsigned char MyDelay;    // is decremented by ISR

unsigned int  ReceivedAdr;         // last received
unsigned char ReceivedCommand;


// -- Data for Motor

unsigned char act_speed;     // aktuelle Einstellung PWM 0-254
unsigned char ziel_speed;    // Zieleinstellung

unsigned char max_speed;     // "konstante" der Maximal Geschwindigkeit
unsigned char slow_speed;    // "konstante" der Anlege Geschwindigkeit



//-----------------------------------------------------------------------------
// data in EEPROM:
//
unsigned char EE_empty     EEMEM = 0xff; // keep free
unsigned char EE_myAdrL    EEMEM = 0x03; // Decoder Adresse low (=Default lt. NMRA)
unsigned char EE_myAdrH    EEMEM = 0;    // Decoder Adresse high
unsigned char EE_myOpMode  EEMEM = 1;    // middle speed
unsigned char EE_LastState EEMEM = 0;    // aktueller Portzustand

unsigned char EE_v_max[8] EEMEM =
              { 250, 225, 200, 175, 150, 200, 175, 150};
unsigned char EE_v_min[8] EEMEM =
              {  60,  60,  60,  60,  60,  50,  50,  50};

//
//---------------------------------------------------------------------------------
// Some tricks to optmize size and speed:
//
// 1. Save global flags (like Communicate or dcc.state) in unused IOs
// 2. Speed up port access by declaring port access as inline code
// 3. Cast logical operation down to char, whenever possible.
//    use assign to local variable and compare this var - smaller size
// 4. Same code in different cases should be identically ordered -
//    gcc reuses this code!
//
// Trick 1: Using IO as variables - what are unused IOs on ATtiny2313:
//   GPIOR0, GPIOR1, GPIOR2 General Purpose I/O Register 
//   UBRRL Baudrate, (USIDR USI Data Register)
//
     #define OPTIMIZE_VARS
//
//   We use:
//      GPIOR0 for general communication between processes
//      GPIOR1 for DCC ISR
    
     #ifdef OPTIMIZE_VARS
         #define Communicate GPIOR0
         #define Recstate GPIOR1
     #elif
         unsigned char Communicate;
         unsigned char Recstate;         
     #endif


// Trick 2: Speed up port access by declaring port access as inline code
//          This is done with a subroutine; if gcc runs with -os, this results in
//          single cbi and sbi statements!

static inline void output(unsigned char port, unsigned char state) 
       __attribute__((always_inline));

void output(unsigned char port, unsigned char state)
  {
    if (state == 0)
      {                              
        PORTB &= (~(1<<port));
      }
    else
      {
        PORTB |= (1<<port);
      }
  }
                      


//----------------------------------------------------------------------------------
// Definitions for inter process communication


#define C_Received        0    // a new DCC was received - issued by ISR(Timer1)
                               //                          cleared by main
#define C_DoSave          1    // a new PORT state should be saved
                               //                        - issued by action
                               //                          cleared by main
    

#define C_DoTimestep      2		// advanced speed of Motor
								//						issued by Timer0 ISR
								//                      cleared by main

#define C_KeyEnabled      3     // Tastendruck erlaubt

#define C_DCC_KeyA        4     // DCC hat Richtung A gedr�ckt
                                //                      issued by Action
                                //                      cleared by Move Control

#define C_DCC_KeyB        5     // DCC hat Richtung B gedr�ckt
                                //                      issued by Action
                                //                      cleared by Move Control

#define C_Oscillate       6     // Pendelfahrt
                                //                      issued by Action
                                //                      cleared by Action



void init_main(void)
  {
    DDRB  = (0 << KEY_GO_A)        // B0 as input
          | (0 << KEY_GO_B)        // B1 as input
          | (1 << MOTOR_PWM)       // B2 as output
          | (1 << MOTOR_DIR)       // B3 as output
          | (0 << STOP_A)          // B4 as input
          | (0 << BRAKE_A)         // B5 as input
          | (0 << STOP_B)          // B6 as input
          | (0 << BRAKE_B);        // B7 as input

    PORTB = (1 << KEY_GO_A)        // pullup
          | (1 << KEY_GO_B)        // pullup
          | (0 << MOTOR_PWM)       // 
          | (0 << MOTOR_DIR)       // 
          | (1 << STOP_A)          // pullup
          | (1 << BRAKE_A)         // pullup
          | (1 << STOP_B)          // pullup
          | (1 << BRAKE_B);        // pullup


    DDRD  = 0xFF                // PortD: all output but:
          & ~(1<<PROGTASTER)    // in - set to 0
          & ~(1<<DCCIN)  
          & ~(1<<JUMPER);
    PORTD =  (1<<PROGTASTER)    // pullup - set to 1
          |  (1<<DCCIN) 
          |  (1<<JUMPER);

    // Init Timer1

    TCCR1B = (0 << ICNC1) 
           | (0 << ICES1) 
           | (0 << WGM13) 
           | (1 << WGM12)       // Mode 4: CTC with OCRA1
           | (0 << CS12)        // clk stopped
           | (0 << CS11) 
           | (0 << CS10);


    // set Timer Compare to 3/4 of period of a one -> this is 116*0,75=87us
    
    OCR1A = F_CPU * PERIOD_1 * 3 / 4 / 1000000L;  


    // Init Timer0 as Phase Correct PWM
    
    OCR0A = 0;                  // PWM of Motor disable 

    TCCR0A = (1 << COM0A1)      // compare match A overrides pin (non inverting)
           | (0 << COM0A0) 
           | (0 << COM0B1)      // compare match B inactiv
           | (0 << COM0B0) 
           | 0                  // reserved
           | 0                  // reserved
           | (0 << WGM01)  
           | (1 << WGM00);      // Timer0 Mode 1 = phase correct pwm (0..255)
    TCCR0B = (0 << FOC0A) 
           | (0 << FOC0B) 
           | (0 << WGM02) 
    #if   TIMER0_CLKDIV == 1
           | (0 << CS02) | (0 << CS01)  | (1 << CS00);       // CS[2:0]=001 clkdiv 1
    #elif TIMER0_CLKDIV == 8
           | (0 << CS02) | (1 << CS01)  | (0 << CS00);       // CS[2:0]=010 clkdiv 8
    #elif TIMER0_CLKDIV == 64
           | (0 << CS02) | (1 << CS01)  | (1 << CS00);       // CS[2:0]=011 clkdiv 64 
    #elif TIMER0_CLKDIV == 256
           | (1 << CS02) | (0 << CS01)  | (0 << CS00);       // CS[2:0]=100 clkdiv 256
    #elif TIMER0_CLKDIV == 1024
           | (1 << CS02) | (0 << CS01)  | (1 << CS00);       // CS[2:0]=101 clkdiv 1024   
    #else
     #warning: TIMER0_CLKDIV is void
    #endif


    TIMSK = (0<<TOIE1)       // Timer1 Overflow
          | (1<<OCIE1A)      // Timer1 Compare A
          | (0<<OCIE1B)      // Timer1 Compare B
          | 0                // reserved
          | (0<<ICIE1)       // Timer1 Input Capture
          | (0<<OCIE0B)      // Timer0 Compare B
          | (1<<TOIE0)       // Timer0 Overflow
          | (0<<OCIE0A);     // Timer0 Compare A



    // Init Interrupt 0

    GIMSK = (0<<INT1)        // Int1 is msb
          | (1<<INT0)        // Enable INT0
          | (0<<PCIE); 


    MCUCR = 0x03;  //           ;The rising edge of INT0 generates an interrupt request.
          
  }


//==============================================================================
//
// Section 2
//
// DCC Receive Routine
//
// Howto:    uses two interrupt: a rising edge in DCC polarity triggers INT0;
//           in INT0, Timer1 with a delay of 87us is started.
//           On Timer1 Compare Match the level of DCC is evaluated and
//           parsed.
//
//                           |<-----116us----->|
//
//           DCC 1: _________XXXXXXXXX_________XXXXXXXXX_________
//                           ^-INT0
//                           |----87us--->|
//                                        ^-INT1: reads zero
//
//           DCC 0: _________XXXXXXXXXXXXXXXXXX__________________
//                           ^-INT0
//                           |----------->|
//                                        ^-INT1: reads one
//           
// Result:   1. The received message is stored in "message" and "message_size"
//           2. The flag C_Received is set.
//
#define MAX_MESSAGE 6    // including XOR-Byte
volatile unsigned char message[MAX_MESSAGE];
volatile unsigned char message_size;

struct
    {
        unsigned char state;                    // current state
        unsigned char bitcount;                 // current bit
        unsigned char bytecount;                // current byte
        unsigned char accubyte;                 // actual check
    } dccrec;

// some states:
#define RECSTAT_WF_PREAMBLE  0
#define RECSTAT_WF_LEAD0     1
#define RECSTAT_WF_BYTE      2
#define RECSTAT_WF_TRAILER   3

#define RECSTAT_DCC          7   


// ISR(INT0) loads only a register and stores this register to IO.
// this influences no status flags in SREG.
// therefore we define a naked version of the ISR with
// no compiler overhead.

#define ISR_INT0_OPTIMIZED

#ifdef ISR_INT0_OPTIMIZED
    #define ISR_NAKED(vector) \
        void vector (void) __attribute__ ((signal, naked)); \
        void vector (void)

    ISR_NAKED(INT0_vect) 
      {
         __asm__ __volatile 
          (
            "push r16"  "\n\t"
            "ldi r16, %1"  "\n\t"
            "out %0, r16" "\n\t"
            "pop r16"  "\n\t"
         :                         // no output section
         : "M" (_SFR_IO_ADDR (TCCR1B)),
           "M" ((0 << ICNC1)       // start timer1
              | (0 << ICES1) 
              | (0 << WGM13) 
              | (1 << WGM12)       // Mode 4: CTC
              | (0 << CS12)        // clk 1:1
              | (0 << CS11) 
              | (1 << CS10))
          );
        asm volatile ( "reti" ); 
      }
#else
    ISR(INT0_vect) 
      {
        TCCR1B = (0 << ICNC1)       // start timer1
               | (0 << ICES1) 
               | (0 << WGM13) 
               | (1 << WGM12)       // Mode 4: CTC
               | (0 << CS12)        // clk 1:1
               | (0 << CS11) 
               | (1 << CS10); 
      }

#endif

unsigned char copy[] PROGMEM = {"MoveDecoder v0.1 (c) Kufer 2006"};

ISR(TIMER1_COMPA_vect)
  {
    #define mydcc (Recstate & (1<<RECSTAT_DCC))

    // read asap to keep timing!
    if (PIND & (1<<DCCIN)) Recstate &= ~(1<<RECSTAT_DCC);  // if high -> mydcc=0
    else                   Recstate |= 1<<RECSTAT_DCC;    

    TCCR1B = (0 << ICNC1)       
           | (0 << ICES1) 
           | (0 << WGM13) 
           | (1 << WGM12) 
           | (0 << CS12)        // clk stopped
           | (0 << CS11) 
           | (0 << CS10);

    TCNT1 = 0;                  // clear Counter

    dccrec.bitcount++;

    if (Recstate & (1<<RECSTAT_WF_PREAMBLE))            // wait for preamble
      {                                       
        if (mydcc)
          {
            if (dccrec.bitcount > 10) 
              {
                Recstate = 1<<RECSTAT_WF_LEAD0;            
              }
          }
        else
          {
            dccrec.bitcount=0;
          }
      }
    else if (Recstate & (1<<RECSTAT_WF_LEAD0))          // wait for leading 0
      {
        if (mydcc)
          {                                             // still 1, wait again
          }
        else
          {
            dccrec.bytecount=0;
            Recstate = 1<<RECSTAT_WF_BYTE;
            dccrec.bitcount=0;
            dccrec.accubyte=0;
          }
      }
    else if (Recstate & (1<<RECSTAT_WF_BYTE))           // wait for byte
      {
        unsigned char my_accubyte;
        my_accubyte = dccrec.accubyte << 1;
        if (mydcc)
          {
            my_accubyte |= 1;
          }
        dccrec.accubyte = my_accubyte;
        
        /* dccrec.accubyte = dccrec.accubyte << 1;
        if (mydcc)
          {
            dccrec.accubyte |= 1;
          }
         */
        if (dccrec.bitcount==8)
          {
            if (dccrec.bytecount == MAX_MESSAGE)        // too many bytes
              {                                         // ignore message
                Recstate = 1<<RECSTAT_WF_PREAMBLE;   
              }
            else
              {
                message[dccrec.bytecount++] = dccrec.accubyte;
                Recstate = 1<<RECSTAT_WF_TRAILER; 
              }
          }
      }
    else if (Recstate & (1<<RECSTAT_WF_TRAILER))        // wait for 0 (next byte) 
      {                                                 // or 1 (eof message)
        if (mydcc)
          {  // trailing "1" received
            Recstate = 1<<RECSTAT_WF_PREAMBLE;
            dccrec.bitcount=1;
            message_size = dccrec.bytecount;
            Communicate |= (1<<C_Received);
          }
        else
          {
            Recstate = 1<<RECSTAT_WF_BYTE;
            dccrec.bitcount=0;
            dccrec.accubyte=0;
          }
      }
    else
      {
        Recstate = 1<<RECSTAT_WF_PREAMBLE;
      }
  }

#if (SIMULATION == 1)

unsigned char dccbit;
void simulat_receive(void);

void dcc_receive(void)
  {
    #define mydcc dccbit

    dccrec.bitcount++;

    if (Recstate & (1<<RECSTAT_WF_PREAMBLE))            // wait for preamble
      {                                       
        if (mydcc)
          {
            if (dccrec.bitcount > 10) 
              {
                Recstate = 1<<RECSTAT_WF_LEAD0;            
              }
          }
        else
          {
            dccrec.bitcount=0;
          }
      }
    else if (Recstate & (1<<RECSTAT_WF_LEAD0))          // wait for leading 0
      {
        if (mydcc)
          {                                             // still 1, wait again
          }
        else
          {
            dccrec.bytecount=0;
            Recstate = 1<<RECSTAT_WF_BYTE;
            dccrec.bitcount=0;
            dccrec.accubyte=0;
          }
      }
    else if (Recstate & (1<<RECSTAT_WF_BYTE))           // wait for byte
      {
        dccrec.accubyte = dccrec.accubyte << 1;
        if (mydcc)
          {
            dccrec.accubyte |= 1;
          }
        if (dccrec.bitcount==8)
          {
            if (dccrec.bytecount == MAX_MESSAGE)        // too many bytes
              {                                         // ignore message
                Recstate = 1<<RECSTAT_WF_PREAMBLE;   
              }
            else
              {
                message[dccrec.bytecount++] = dccrec.accubyte;
                Recstate = 1<<RECSTAT_WF_TRAILER; 
              }
          }
      }
    else if (Recstate & (1<<RECSTAT_WF_TRAILER))        // wait for 0 (next byte) 
      {                                                 // or 1 (eof message)
        if (mydcc)
          {  // trailing "1" received
            Recstate = 1<<RECSTAT_WF_PREAMBLE;
            dccrec.bitcount=1;
            message_size = dccrec.bytecount;
            Communicate |= (1<<C_Received);
          }
        else
          {
            Recstate = 1<<RECSTAT_WF_BYTE;
            dccrec.bitcount=0;
            dccrec.accubyte=0;
          }
      }
    else
      {
        Recstate = 1<<RECSTAT_WF_PREAMBLE;
      }
  }

#endif   // SIMULATION == 1



//==============================================================================
//
// Section 3
//
// Timing Engine
//
// Howto:    Timer0 Overflow is called every 51us (510 * t(cycle))
//           it counts and generates a communcation flag when it reaches max.
// 
//  

 
volatile unsigned int sw_timer0;           // Note: ev. als unsigned char



ISR(TIMER0_OVF_vect)                      // Timer0 Compare Int
  {
    unsigned int my_timer0; 

    my_timer0 = sw_timer0;                   
    
	my_timer0++;
	
	if (my_timer0 == SW_TIMER_MAX)
	  {
	    my_timer0 = 0;
		Communicate |= (1<<C_DoTimestep);
        if (MyDelay) MyDelay--;                  // Debounce
	  }

    sw_timer0 = my_timer0;    
  }


// Timer0 l�uft mit 10MHz, kein prescaler als Phase Correct PWM.
// d.h. PWM-Frequenz ist 10M / 510 = 19,6kHz
// WGM 2:0 = 1, Top ist damit 0xff

// wenn OCR0A == BOOTOM: output -> cont. low
// wenn OCR0A = MAX: output cont. high (non inverted PWM)


//==============================================================================
//
// Section 4
//
// Motor Engine
//
// Howto:    motor_control keeps the states of the motor, asks the keys and
//           modifies current pwm value.
//           Timing is given by Timer0 through ISR and C_DoTimestep
// 
//  

unsigned int osc_delay;


void check_oscillate(void)
  {
    if (Communicate & (1<<C_Oscillate))    
	  {
	    osc_delay++;
        if (osc_delay == (OSCILLATE_TIME / SW_TICK_PERIOD))     // 60 sec
          {
            osc_delay = 0;
            if (move_state == MS_AT_A) Communicate |= (1<<C_DCC_KeyB);   // simulate a keystroke
            if (move_state == MS_AT_B) Communicate |= (1<<C_DCC_KeyA); 
          }
	  }
  }




void check_speed_change(void)
  {
    if (Communicate & (1<<C_DoTimestep))         // this flag is set every 5.1ms
	  {
	    Communicate &= ~(1<<C_DoTimestep); 

	    if (act_speed > ziel_speed)
    	  {
        	act_speed--;
        	OCR0A = act_speed; 
	      }
    	else if (act_speed < ziel_speed)
      	  {
	        if (act_speed == 0)
              { 
                act_speed = slow_speed;          // skip void area from 0 to slow_speed
        	    OCR0A = act_speed; 
              }
            else
              {
                act_speed++;
        	    OCR0A = act_speed; 
              }
	      }

        check_oscillate();
	  }
  }


void set_speed(unsigned char speed)
  {
    ziel_speed = speed;
    if (speed == 0)
      {
         act_speed = 0;
         OCR0A = 0;          // set to 0: continous signal;
      }
  }
  

void move_control(void)
  {   
    switch(move_state)
      {
        case MS_RUN_TO_A:
                if (BRAKE_A_REACHED)  
                  {
                    set_speed(slow_speed);              // reduce speed
                  }
                if (  (STOP_A_REACHED) || 
                      (KEY_GO_A_PRESSED && KEY_GO_B_PRESSED) || // both keys simultaneaously
                      (Communicate & (1<<C_DCC_KeyB))                )
                  {
                    Communicate &= ~(1<<C_DCC_KeyB);
                    set_speed(0);
                    MOTOR_TO_B;
                    move_state = MS_AT_A;
                  }
                break;
        case MS_RUN_TO_B:
                if (BRAKE_B_REACHED)
                  {
                    set_speed(slow_speed);
                  }
                if (  (STOP_B_REACHED) ||
                      (KEY_GO_A_PRESSED && KEY_GO_B_PRESSED)  || // both => emerg. stop
                      (Communicate & (1<<C_DCC_KeyA))   )
                  { 
                    Communicate &= ~(1<<C_DCC_KeyA); 
                    set_speed(0);
                    MOTOR_TO_A;
                    move_state = MS_AT_B;
                  }
                break;
       case MS_AT_A:
                Communicate &= ~(1<<C_DCC_KeyA);        // we are at A: clear any pending key

               if (  ((Communicate & (1<<C_KeyEnabled)) && KEY_GO_B_PRESSED) 
                   || (Communicate & (1<<C_DCC_KeyB)) )
                  {
                        MOTOR_TO_B;
                        set_speed(max_speed);
                        move_state = MS_RUN_TO_B;                   
                  }
                break; 
        case MS_AT_B:
                Communicate &= ~(1<<C_DCC_KeyB);        // we are at B: clear any pending key
                
                if (  ((Communicate & (1<<C_KeyEnabled)) && KEY_GO_A_PRESSED) 
                   || (Communicate & (1<<C_DCC_KeyA)) )
                  {
                        MOTOR_TO_A;
                        set_speed(max_speed);
                        move_state = MS_RUN_TO_A;
                  }
                break;
        case MS_STOPPED:                               // initial state
                if (STOP_B_REACHED)
                  {
                    set_speed(0);
                    MOTOR_TO_A;
                    move_state = MS_AT_B;
                  }
                else if (STOP_A_REACHED)
                  {
                    set_speed(0);
                    MOTOR_TO_B;
                    move_state = MS_AT_A;
                  }
				else
				  {                                    // try slow movement to A
				    MOTOR_TO_A;
				  	set_speed(2*slow_speed);           // double speed, to start motor
				  }
                break; 
      }
	check_speed_change();
  }


//==============================================================================
//
// Section 5
//
// MAIN: analyze command, call the action, do programming
//
//

//------------------------------------------------------------------------------
// This Routine is called when myAdr is received



void action(void)
  {
    unsigned char myCommand;
    
    if (ReceivedCommand & (1<<3))   // Bit 3: accessory command + active coil?
      {
        myCommand = ReceivedCommand & 0b00000111;

        cli();                      // block interrupts
        
        Communicate |= (1<<C_DoSave); 

        if (myCommand == 0)      // = F�hre komplett abschalten
          {
			Communicate &= ~(1<<C_DCC_KeyA);
			Communicate &= ~(1<<C_DCC_KeyB);
			Communicate &= ~(1<<C_KeyEnabled);
            Communicate &= ~(1<<C_Oscillate);
	      }
        else if (myCommand == 1) // = F�hre einschalten
          {
			Communicate |= (1<<C_KeyEnabled);
	      }
		else if (myCommand == 2) // = F�hre nach A
          {
            Communicate |= (1<<C_DCC_KeyA);
	      }                     
        else if (myCommand == 3) // = F�hre nach B
          {
            Communicate |= (1<<C_DCC_KeyB);
		  }
        else if (myCommand == 4) // = F�hre pendelt alle 60 sec.
          {
            osc_delay = (OSCILLATE_TIME / SW_TICK_PERIOD) - 1;  // damit gehts gleich los
            Communicate |= (1<<C_Oscillate);           
          }
        else if (myCommand == 5) // = unused
          {
          }
        else if (myCommand == 6) // = unused
          {
          }                     
        else // (myCommand == 7) // unused
          {
          }             
        sei();
     }
  }

//-----------------------------------------------------------------------------
// analyze_message checks the received DCC message
// return 0 if void, 1 if accessory command, 2 if myAdr;
//
unsigned char analyze_message(void)
  {
    unsigned char i;
    unsigned char myxor = 0;
    unsigned int MyAdr;
    
    for (i=0; i<message_size; i++)
      {
        myxor = myxor ^ message[i];
      }

    if (myxor)
      {
        // checksum error, ignore
        return(0);
      }
    else
      {
        // check, if it is an accessory message (128-192)
        myxor = message[0] & 0b11000000;
        if (myxor == 0b10000000)
          {
            if (message[1] >= 0b10000000)  // MSB in Command byte set
              {
                ReceivedCommand = message[1] & 0b00001111;
    
                // take bits 5 4 3 2 1 0 from message[0]
                // take Bits 6 5 4 from message[1] and invert
    
                #define OPTCODE1
                #ifdef OPTCODE1
                    unsigned char temp;
                    myxor = ~message[1] & 0b01110000;
                    myxor = myxor<<1;  // shift as byte
                    temp = message[0] & 0b00111111;
                    ReceivedAdr = (myxor<<1) | temp;
                #else 
                    ReceivedAdr = (message[0] & 0b00111111)
                                | ((~message[1] & 0b01110000) << 2);
                #endif
    
                MyAdr = (eeprom_read_byte(&EE_myAdrH) << 8) |
                        (eeprom_read_byte(&EE_myAdrL));
    
                if (ReceivedAdr == MyAdr) return(2);
                else return(1);
              }
          }
      }
    return(0);
  }


//------------------------------------------------------------------------
// This Routine is called when PROG is pressed
//
#define DEBOUNCE  (80000L / SW_TICK_PERIOD)
#if (DEBOUNCE == 0)
 #define DEBOUNCE  1
#endif

#define BLINK_TIME (200000L / SW_TICK_PERIOD)


void DoProgramming(void)
  {
    unsigned char myCommand;    

    cli();
    MyDelay = DEBOUNCE;
    sei();

    while(MyDelay) ;     // wait until ISR has decremented  MyDelay

    if (PROG_PRESSED)                    // still pressed?
      {
        LED_ON;
        // while(!PROG_PRESSED) ;           // wait for release (XXX)
        Communicate &= ~(1<<C_Received);

        while(1)       // while(!PROG_PRESSED) (XXX)
          {
            if (Communicate & (1<<C_Received))
              {                                     // Message
                Communicate &= ~(1<<C_Received);
                if (analyze_message())              // Accessory
                  {
                    eeprom_write_byte(&EE_myAdrL, (unsigned char) ReceivedAdr);     
                    eeprom_write_byte(&EE_myAdrH, (unsigned char) (ReceivedAdr >> 8));
                    
                    myCommand = ReceivedCommand & 0x07;
                    eeprom_write_byte(&EE_myOpMode, myCommand);
                    MyOpMode = myCommand;

                    eeprom_write_byte(&EE_LastState, 0);
                    
                    do {} while (!eeprom_is_ready());    // wait for write to complete

                    LED_OFF;

                    // we got reprogrammed ->
                    // forget everthing running and restart decoder!                    
                    
                 
                    unsigned char i;
                    for (i=0; i<10; i++)                 // show ack
                      {
                         cli();
                         MyDelay = BLINK_TIME;
                         sei();
                         while(MyDelay);
                         LED_TOGGLE;
                      }
     
                    // laut diversen Internetseiten sollte folgender Code laufen -
                    // tuts aber nicht, wenn man das Assemblerlistung ansieht.
                    // void (*funcptr)( void ) = 0x0000;    // Set up function pointer
                    // funcptr();                        // Jump to Reset vector 0x0000
                    
                    __asm__ __volatile 
                    (
                       "ldi r30,0"  "\n\t"
                       "ldi r31,0"  "\n\t"
                       "icall" "\n\t"
                     );
                    
                    // return;  

                  }
              }

          }  // while
      }
    LED_OFF;
    return;   
  }


int main(void)
  {
    init_main();
     
     // Lese die eigene DCC-Adresse und Betriebsart

    // MyAdr = (eeprom_read_byte(&EE_myAdrH) << 8) |
    //         (eeprom_read_byte(&EE_myAdrL));

    MyOpMode  = eeprom_read_byte(&EE_myOpMode);
    max_speed = eeprom_read_byte(&EE_v_max[MyOpMode]);
    slow_speed = eeprom_read_byte(&EE_v_min[MyOpMode]);

    Communicate = 0; 
    Communicate |= (1<<C_KeyEnabled);  // = F�hre einschalten
    Recstate = 1<<RECSTAT_WF_PREAMBLE;
    
        #if (SIMULATION == 2)
          sei();
          while(1)
            {
              if (act_speed == 0) set_speed(250);
              if (act_speed == 250) set_speed(0);
              check_speed_change();
            }
        #endif

        #if (SIMULATION == 3)
        #endif


        #if (SIMULATION == 1)
          simulat_receive();
        #endif

    sei();              // Global enable interrupts
    
    while(1)
      {
	    move_control();
        cli();
        if (Communicate & (1<<C_Received)  )
          {
            sei();
            if (analyze_message() == 2)     // MyAdr empfangen
              {
                action();
              }
            Communicate &= ~(1<<C_Received); 
          }
        sei();

        cli();
        if (Communicate & (1<<C_DoSave) )
          {
            sei();
            Communicate &= ~(1<<C_DoSave);
            if (JUMPER_FITTED)
              {
                eeprom_write_byte(&EE_LastState, PORTB);   
              } 
          } 
        sei();

        if (PROG_PRESSED) DoProgramming();         
      }
  }


//===========================================================================
//
// Simulationen:
//
// 0: keine Simulation
// 1: Test der Empfangroutine; hierzu ein DCC Generator (aus opendcc/dccout.c)
// 2: Test der Portengine
//
#if (SIMULATION == 1)

//                                        Adressbyte   Datenbyte 
//                                         10AAAAAA    1aaaSCCR    // note: aaa = ~AAA
unsigned char message_adr001_out0_g[] = {0b10000001, 0b11111001};
unsigned char message_adr005_out1_g[] = {0b10000101, 0b11111011};
unsigned char message_adr380_out0_g[] = {0b10111100, 0b10101001};  // 380 = 0x17C = 0b101111100


// upstream interface:
struct
  {
    unsigned char size;
    unsigned char dcc[5];
  } next_message;

volatile unsigned char next_message_count;

enum do_states
  {                            // actual state
     dos_idle,
     dos_send_preamble,
     dos_send_bstart,
     dos_send_byte,
     dos_send_xor
  };

struct
  {
    enum do_states state;

    unsigned char ibyte;                            // current index of byte in message
    unsigned char bits_in_state;                    // Bits to output in this state
    unsigned char cur_byte;                         // current byte
    unsigned char xor_byte;                              // actual xor
    unsigned char current_dcc[5];                  // current message in output processing
    unsigned char bytes_in_message;                 // current size of message (decremented)
    unsigned char phase;
  } doi;


unsigned char dccbit;

void do_send(unsigned char mydccbit)
  {
    dccbit = mydccbit;
  }

void dcc_bit_generator(void)
  {
    switch (doi.state)
      {
        case dos_idle:
            do_send(1);
            if (next_message_count > 0)
              {
                memcpy(doi.current_dcc, next_message.dcc, sizeof(doi.current_dcc));
                doi.bytes_in_message = next_message.size;
                // no size checking - if (doi.cur_size > 5) doi.cur_size = 5;
                next_message_count--;
                doi.ibyte = 0;
                doi.xor_byte = 0;
                doi.bits_in_state = 14;
                doi.state = dos_send_preamble;
              }
            break;

        case dos_send_preamble:
            do_send(1);
            doi.bits_in_state--;
            if (doi.bits_in_state == 0)
                 doi.state = dos_send_bstart;
            break;

        case dos_send_bstart:
            do_send(0);
            if (doi.bytes_in_message == 0)
              { // message done, goto xor
                doi.cur_byte = doi.xor_byte;
                doi.state = dos_send_xor;
                doi.bits_in_state = 8;
              }
            else
              { // get next addr or data
                doi.bytes_in_message--;
                doi.cur_byte = doi.current_dcc[doi.ibyte++];
                doi.xor_byte ^= doi.cur_byte;
                doi.state = dos_send_byte;
                doi.bits_in_state = 8;
              }
            break;

        case dos_send_byte:
            if (doi.cur_byte & 0x80) do_send(1);
            else                    do_send(0);
            doi.cur_byte <<= 1;
            doi.bits_in_state--;
            if (doi.bits_in_state == 0)
              {
                doi.state = dos_send_bstart;
              }
            break;

        case dos_send_xor:
            if (doi.cur_byte & 0x80) do_send(1);
            else                    do_send(0);
            doi.cur_byte <<= 1;
            doi.bits_in_state--;
            if (doi.bits_in_state == 0)
              {
                doi.state = dos_idle;
              }
            break;
     }
  }

void dcc_generate_init(void)
  {
    doi.state = dos_idle;
  }


void simulat_receive(void)
  {
    dcc_generate_init();
    dcc_bit_generator();
    dcc_bit_generator();
    memcpy(next_message.dcc, message_adr001_out0_g, sizeof(doi.current_dcc));
    next_message.size = 2;
    next_message_count = 2;
    while(1)
      {
        dcc_bit_generator();
        dcc_receive();

        if (Communicate & (1<<C_Received)  )
          {
            if (analyze_message() == 2)     // MyAdr empfangen
              {
                action();
              }
            Communicate &= ~(1<<C_Received); 
          }
        if (Communicate & (1<<C_DoSave) )
          {
            Communicate &= ~(1<<C_DoSave);
            if (JUMPER_FITTED)
              {
                eeprom_write_byte(&EE_LastState, PORTB);   
              } 
          } 
        // if (PROG_PRESSED) DoProgramming();         
      }
 
  }


#endif
